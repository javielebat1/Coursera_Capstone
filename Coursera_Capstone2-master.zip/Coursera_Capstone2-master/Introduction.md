Question :1 : Introduction/Business Problem 

Capstone Project - The Battle of Neighbourhoods
Introduction / Business Problem :

"Need to find locality of all the cities in United States would be the best place to start a restaurant?"

Client interested in starting a restaurant in the best locality of all the cities in United states. Location defines a best locatlity based on the following constraints,

Population density of a locality
Per Capital income
Population of each location
Venues in each locality
The category of the venues that he's interested in are,

Arts and Entertainment
Shops & Service
College and University
Event
Food
Travel & Transport