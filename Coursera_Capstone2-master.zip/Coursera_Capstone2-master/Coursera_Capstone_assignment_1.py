#!/usr/bin/env python
# coding: utf-8

# My First capstone project

# In[2]:


import pandas as pd 
import numpy as np


# In[7]:


print ('Hello Capstone Project Course!')


# In[ ]:




