print ("Hello World")

